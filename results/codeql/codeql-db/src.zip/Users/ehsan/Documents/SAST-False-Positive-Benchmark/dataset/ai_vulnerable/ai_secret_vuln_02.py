api_key = "sk_test_1234567890abcdef"

print(api_key)
